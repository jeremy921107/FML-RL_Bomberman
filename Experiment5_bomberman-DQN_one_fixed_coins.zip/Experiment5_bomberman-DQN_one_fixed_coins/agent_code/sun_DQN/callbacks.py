import numpy as np
from .DQN import DQN
from keras.models import load_model


def setup(self):

    self.total_step = 0
    self.reward = 0
    self.actions = ['UP', 'DOWN', 'LEFT', 'RIGHT', 'WAIT']
    self.states = []
    self.deepQ = DQN(action_size=5, state_size=243)
    # self.deepQ.Q.load_weights('dqn_mse_adam.h5')



def act(self):
    self.s = get_state(self)
    self.a = self.deepQ.act(self.s) # the action are represented as [0,1,2,3,4,5]
    self.next_action = self.actions[self.a]

    return self.next_action


def reward_update(self):
    self.s_ = get_state(self)

    r = reward(self.events)

    self.deepQ.store_memory(self.s,self.a,r,self.s_,0)

    if self.total_step > self.deepQ.memory_size and self.total_step % self.deepQ.replay_iter == 0:
        self.logger.debug('Learning at step ' + str(self.total_step))
        self.deepQ.learn(32)

    self.total_step += 1

def end_of_episode(self):
    self.s_ = np.zeros(243)
    r = reward(self.events)
    self.deepQ.store_memory(self.s,self.a,r,self.s_,1)

    if self.total_step > self.deepQ.memory_size and self.total_step % self.deepQ.replay_iter == 0:
        self.deepQ.learn(32)

    self.total_step += 1

    with open('loss.txt', 'w') as op:
        op.write(str(self.deepQ.loss))

    with open('q_pred.txt', 'w') as op:
        op.write(str(self.deepQ.q_pred))

    self.deepQ.Q.save('training_model.h5')


# ---------------------auxiliary functions---------------------------- #


def get_state(agent):
    arena = agent.game_state['arena']

    arena_agent = np.zeros(arena.shape)
    self_x, self_y, self_name, bomb_flag, score = agent.game_state['self']
    arena_agent[self_x][self_y] = 1

    coins = agent.game_state['coins']
    arena_coin = np.zeros(agent.game_state['arena'].shape)
    for x, y in coins:
        arena_coin[x][y] = 1

    state = np.hstack((arena.flatten(), arena_agent.flatten(), arena_coin.flatten()))
    return state


def reward(events):
    """
            'MOVED_LEFT': 0
            'MOVED_RIGHT':1
            'MOVED_UP':   2
            'MOVED_DOWN': 3
            'WAITED':     4
            'INTERRUPTED':5
            'INVALID_ACTION:6

            'BOMB_DROPPED': 7
            'BOMB_EXPLODED':8

            'CRATE_DESTROYE:9
            'COIN_FOUND':   10
            'COIN_COLLECTED:11

            'KILLED_OPPONEN:12
            'KILLED_SELF':  13

            'GOT_KILLED':   14
            'OPPONENT_ELIMI:15
            'SURVIVED_ROUND:16
    """
    reward_list = {4:-10,6:-10,11:30}
    reward = sum([reward_list[e] for e in events if e in reward_list])
    return reward






