import numpy as np
from .Qtable import QLearningTable
import pandas as pd



def setup(self):
    self.reward = 0
    self.Q = QLearningTable()

def act(self):

    self.s = get_state(self) # current state
    self.logger.info('choose action from q table based on current state')
    self.next_action = self.Q.choose_action(str(self.s))
    print(self.next_action)

def reward_update(self):
    self.s_ = get_state(self) # next state

    a = self.next_action

    reward = reward(self.events)

    self.Q.learn(str(self.s), a, reward, str(self.s_))
    print(self.Q.q_table)


def end_of_episode(self):

    self_x, self_y, self_name, bomb_flag, score = self.game_state['self']
    print(self.s)

    self.s_ = 'terminal'
    a = self.next_action
    reward = reward(self.events)
    self.Q.learn(str(self.s), a, reward, str(self.s_))

    print(self.Q.q_table)
    self.Q.q_table.to_excel('Q_table.xlsx')


def get_state(agent):

    self_x, self_y, self_name, bomb_flag, score = agent.game_state['self']

    coin_x, coin_y = agent.game_state['coins'][0]

    s = [self_x,self_y,coin_x,coin_y]

    return s

def reward(events):
    '''
            'MOVED_LEFT': 0
            'MOVED_RIGHT':1
            'MOVED_UP':   2
            'MOVED_DOWN': 3
            'WAITED':     4
            'INTERRUPTED':5
            'INVALID_ACTION:6

            'BOMB_DROPPED': 7
            'BOMB_EXPLODED':8

            'CRATE_DESTROYE:9
            'COIN_FOUND':   10
            'COIN_COLLECTED:11

            'KILLED_OPPONEN:12
            'KILLED_SELF':  13

            'GOT_KILLED':   14
            'OPPONENT_ELIMI:15
            'SURVIVED_ROUND:16
    '''
    reward_dic = {6:-5, 11:50}
    reward = sum([reward_dic[e] for e in events if e in reward_dic])
    return reward




