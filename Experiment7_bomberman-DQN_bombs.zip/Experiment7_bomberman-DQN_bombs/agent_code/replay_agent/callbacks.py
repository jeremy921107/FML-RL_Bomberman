import numpy as np
from .DQN import DQN
from keras.models import load_model


def setup(self):

    self.total_step = 0
    self.reward = 0
    self.actions = ['UP', 'DOWN', 'LEFT', 'RIGHT', 'WAIT', 'BOMB']
    self.states = []
    self.deepQ = DQN(action_size=5, state_size=405)
    self.deepQ.Q.load_weights('training_model.h5')



def act(self):
    self.s = get_state(self)
    self.a = self.deepQ.act(self.s) # the action are represented as [0,1,2,3,4,5]
    self.next_action = self.actions[self.a]

    return self.next_action



# ---------------------auxiliary functions---------------------------- #


def get_state(agent):
    arena = agent.game_state['arena']

    arena_agent = np.zeros(arena.shape)
    self_x, self_y, self_name, bomb_flag, score = agent.game_state['self']
    arena_agent[self_x][self_y] = 1

    coins = agent.game_state['coins']
    arena_coin = np.zeros(agent.game_state['arena'].shape)
    for x, y in coins:
        arena_coin[x][y] = 1

    bombs = agent.game_state['bombs']
    arena_bombs = np.zeros(agent.game_state['arena'].shape)
    for x, y in bombs:
        arena_bombs[x][y] = 1

    exploration = agent.game_state['explosions']

    state = np.hstack(
        (arena.flatten(), arena_agent.flatten(), arena_coin.flatten(), arena_bombs.flatten(), exploration.flatten()))
    # print('len of state is: ', len(state))

    state = np.hstack((arena.flatten(), arena_agent.flatten(), arena_coin.flatten()))
    return state


def reward(events):
    """
            'MOVED_LEFT': 0
            'MOVED_RIGHT':1
            'MOVED_UP':   2
            'MOVED_DOWN': 3
            'WAITED':     4
            'INTERRUPTED':5
            'INVALID_ACTION:6

            'BOMB_DROPPED': 7
            'BOMB_EXPLODED':8

            'CRATE_DESTROYE:9
            'COIN_FOUND':   10
            'COIN_COLLECTED:11

            'KILLED_OPPONEN:12
            'KILLED_SELF':  13

            'GOT_KILLED':   14
            'OPPONENT_ELIMI:15
            'SURVIVED_ROUND:16
    """
    reward_list = {4:-20,6:-10,7:15,9:15,10:15,11:50,13:-50,16:25}
    reward = sum([reward_list[e] for e in events if e in reward_list])
    return reward






