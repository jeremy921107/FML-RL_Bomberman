import numpy as np
import tensorflow as tf
import random
from collections import deque
from keras import backend as K
from keras.models import Sequential
from keras.models import save_model
from keras.layers import Dense, Flatten
from keras.optimizers import RMSprop, Adam


class DQN:


    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size
        self.memory_size = 1000
        self.memory = deque(maxlen=self.memory_size)

        self.gamma = 0.9
        self.epsilon = 0.9
        self.epsilon_min = 0.1
        self.epsilon_decay = 0.95
        self.learning_rate = 0.05

        self.Q = self.build_model()
        self.Q_target = self.build_model()

        self.learn_step_counter = 0
        self.replay_iter = 1
        self.replace_target_iter = 300

        self.loss = []
        self.q_pred = []


    def build_model(self):

        model = Sequential()
        model.add(Dense(50, input_dim=self.state_size, activation='relu'))
        model.add(Dense(30, activation='relu'))
        model.add(Dense(self.action_size, activation='linear'))
        model.compile(loss='mse',
                      optimizer=RMSprop(lr=self.learning_rate))
        return model

    def store_memory(self, state, action, reward, next_state, done):

        self.memory.append((state[np.newaxis, :], action, reward, next_state[np.newaxis, :], done))

    def act(self, state):
        # take action using e policy
        if np.random.rand() < self.epsilon:
            return random.randrange(self.action_size)
        act_values = self.Q.predict(state[np.newaxis, :])

        return np.argmax(act_values[0])

    def learn(self, batch_size):

        minibatch = random.sample(self.memory, batch_size)

        # if not finished
        for state, action, reward, next_state, done in minibatch:
            #Bellmann Equation

            #last step of the episode
            target = reward

            #not last step of the episode
            if not done:
            # experience replayer and followinh Bellman function
                target = (reward + self.gamma * np.amax(self.Q_target.predict(next_state)[0]))

            q = self.Q.predict(state)
            self.q_pred.append(q)

            q_target = q.copy()

            q_target[0][action] = target

            self.train = self.Q.fit(state, q_target, epochs=1, verbose=0)
            loss = self.train.history['loss'][-1]
            self.loss.append(loss)

            if self.learn_step_counter % 100 == 0:
                print('learning step: {}'.format(str(self.learn_step_counter)))
                print('loss is: {}'.format(str(loss)))


            self.learn_step_counter +=1


        # epsilon decay
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

        # replace target-q
        if self.learn_step_counter % self.replace_target_iter == 0:
            self.Q_target.set_weights(self.Q.get_weights())
            print('target has been replaced at learning step: {}'.format(str(self.learn_step_counter)))









