from matplotlib import pyplot as plt
import ast

with open('/Users/xinsun/desktop/FML_final_code/Final_submitted_version/Experiment6_bomberman-DQN_random_coins/agent_code/sun_DQN/loss.txt') as op:
    loss = ast.literal_eval(op.read())

plt.plot(loss)
plt.xlabel('epoch')
plt.ylabel('loss')
plt.show()