import numpy as np
import pandas as pd


class RL(object):
    def __init__(self, action_space, learning_rate=0.05, reward_decay=0.95, e_greedy=0.95):
        self.actions = action_space  # a list
        self.lr = learning_rate
        self.epsilon = e_greedy
        self.gamma = reward_decay

        self.q_table = pd.DataFrame(columns=self.actions, dtype=np.float64)

    def append_new_state(self, state):
        if state not in self.q_table.index:
            self.q_table = self.q_table.append(
                pd.Series(
                    [0]*len(self.actions),
                    index=self.q_table.columns, name=state,
                )
            )

    def choose_action(self, observation):
        self.append_new_state(observation)

        if np.random.rand() < self.epsilon:
            # choose best action
            state_action = self.q_table.loc[observation, :]

            action = np.random.choice(state_action[state_action == np.max(state_action)].index)
        else:
            # choose random action
            action = np.random.choice(self.actions)
        return action



# on-policy Sarsa
class SarsaTable(RL):

    def __init__(self, actions, learning_rate=0.05, reward_decay=0.95, e_greedy=0.95):
        super(SarsaTable, self).__init__(actions, learning_rate, e_greedy, reward_decay)

    def learn(self, s, a, r, s_, a_): # here input tuple is the difference with Q learning
        self.append_new_state(s_)
        q_predict = self.q_table.loc[s, a]

        if s_ != 'terminal':
            q_target = r + self.gamma * self.q_table.loc[s_, a_]  # next state is not terminal
        else:
            q_target = r  # next state is terminal

        # q table update
        self.q_table.loc[s, a] += self.lr * (q_target - q_predict)
