import numpy as np
import time
import sys
if sys.version_info.major == 2:
    import Tkinter as tk
else:
    import tkinter as tk


class Maze(tk.Tk, object):
    def __init__(self):
        super(Maze, self).__init__()
        self.action_space = ['up', 'down', 'right', 'left']
        self.n_actions = len(self.action_space)
        self.n_features = 2
        self.title('DQN maze')
        self.geometry('{0}x{1}'.format(MAZE_H * UNIT, MAZE_H * UNIT))
        self._build_maze()

    def _build_maze(self):
        self.canvas = tk.Canvas(self, bg='white', height=MAZE_H * UNIT, width=MAZE_W * UNIT)

        # create board
        for c in range(0, MAZE_W * UNIT, UNIT):
            x0, y0, x1, y1 = c, 0, c, MAZE_H * UNIT
            self.canvas.create_line(x0, y0, x1, y1)
        for r in range(0, MAZE_H * UNIT, UNIT):
            x0, y0, x1, y1 = 0, r, MAZE_W * UNIT, r
            self.canvas.create_line(x0, y0, x1, y1)

        origin = np.array([20, 20])

        # hell
        hell = []
        hellCenter = []
        a = [1, 3, 5]
        for i in a:
            for j in a:
                hell_center = origin + np.array([UNIT*i, UNIT*j])
                hellCenter.append(list(hell_center))
                hell.append(
                    self.canvas.create_rectangle(
                     hell_center[0] - 15, hell_center[1] - 15,
                     hell_center[0] + 15, hell_center[1] + 15,
                     fill='black')
                )
        #for e in self.hell:
        print('the hell is: ', hell)
        print('the hell_center is: ', hellCenter)


        # create coin
        a = np.random.randint(MAZE_H)
        coin_center = origin + UNIT * a
        print('coin_center is: ', coin_center)

        self.coin = self.canvas.create_oval(
            coin_center[0] - 15, coin_center[1] - 15,
            coin_center[0] + 15, coin_center[1] + 15,
            fill='yellow')


        # create red rect
        self.rect = self.canvas.create_rectangle(
            origin[0] - 15, origin[1] - 15,
            origin[0] + 15, origin[1] + 15,
            fill='red')

        # pack all
        self.canvas.pack()


    def reset(self):
        self.update()
        time.sleep(0.05)
        self.canvas.delete(self.rect)
        self.canvas.delete(self.coin)

        origin = np.array([20, 20])

        self.hellall = []
        hellCenter = []
        a = [1, 3, 5]
        for i in a:
            for j in a:
                hell_center = origin + np.array([UNIT * i, UNIT * j])
                hellCenter.append(list(hell_center))
                '''
                hell.append(
                    self.canvas.create_rectangle(
                        hell_center[0] - 15, hell_center[1] - 15,
                        hell_center[0] + 15, hell_center[1] + 15,
                        fill='black')
                )
                '''
                self.hell = self.canvas.create_rectangle(
                    hell_center[0] - 15, hell_center[1] - 15,
                    hell_center[0] + 15, hell_center[1] + 15,
                    fill='black')
                self.hellall.append(self.hell)

        # create coin
        b = np.random.randint(MAZE_H)

        if b not in a:
            coin_center = origin + np.array([UNIT * b, UNIT * b])
            self.coin = self.canvas.create_oval(
                coin_center[0] - 15, coin_center[1] - 15,
                coin_center[0] + 15, coin_center[1] + 15,
                fill='yellow')
        elif b in a and b != 0:
            b = b-1
            coin_center = origin + np.array([UNIT * b, UNIT * b])
            self.coin = self.canvas.create_oval(
                coin_center[0] - 15, coin_center[1] - 15,
                coin_center[0] + 15, coin_center[1] + 15,
                fill='yellow')
        else:
            coin_center = origin + np.array([UNIT * b, UNIT * b])
            self.coin = self.canvas.create_oval(
                coin_center[0] - 15, coin_center[1] - 15,
                coin_center[0] + 15, coin_center[1] + 15,
                fill='yellow')



        self.rect = self.canvas.create_rectangle(
            origin[0] - 15, origin[1] - 15,
            origin[0] + 15, origin[1] + 15,
            fill='red')
        #print('the rect is: ', self.rect)

        # return observation
        return (np.array(self.canvas.coords(self.rect)[:2]) - np.array(self.canvas.coords(self.coin)[:2]))/(MAZE_H*UNIT)

    def step(self, action):
        s = self.canvas.coords(self.rect)
        print('s is: ', s)
        print(s[0], s[1])

        self.hellcoords = []


        for i in self.hellall:
            self.hellcoords.append(self.canvas.coords(i))
            print('the hell is: ', list(self.canvas.coords(i)))


        base_action = np.array([0, 0])
        if action == 0 and s[1] > UNIT and s[1] > UNIT and [s[0], s[1]-UNIT, s[2], s[3]-UNIT] not in list(self.hellcoords):   # up
            print('(s[0], s[1]-UNIT, s[2], s[3]-UNIT) is: ', [s[0], s[1]-UNIT, s[2], s[3]-UNIT])
            base_action[1] -= UNIT
        elif action == 1 and s[1] < (MAZE_H - 1) * UNIT and [s[0], s[1]+UNIT, s[2], s[3]+UNIT] not in list(self.hellcoords):   # down
            base_action[1] += UNIT
        elif action == 2 and s[0] < (MAZE_W - 1) * UNIT and [s[0]+UNIT, s[1], s[2]+UNIT, s[3]] not in list(self.hellcoords):   # right
            base_action[0] += UNIT
        elif action == 3 and s[0] > UNIT and [s[0]-UNIT, s[1], s[2]-UNIT, s[3]] not in list(self.hellcoords):   # left
            base_action[0] -= UNIT

        #if [base_action[0] base_action[1]] != self.canvas.coords(self.hell1):
        #for i in self.hellcoords

        self.canvas.move(self.rect, base_action[0], base_action[1])  # move agent
        print('base_action[0], base_action[1] is: ', base_action[0], base_action[1])


        next_coords = self.canvas.coords(self.rect)  # next state
        #print('next state is: ', next_coords)

        # reward
        if next_coords == self.canvas.coords(self.coin):
            reward = 1
            done = True

        else:
            reward = 0
            done = False
        s_ = (np.array(next_coords[:2]) - np.array(self.canvas.coords(self.coin)[:2]))/(MAZE_H*UNIT)
        print('s_ is: ', s_)

        print('rect is: ', np.array(self.canvas.coords(self.rect)))
        print('oval is: ', np.array(self.canvas.coords(self.coin)))

        return s_, reward, done


    def render(self):
        self.update()



UNIT = 40 #40   # pixels
MAZE_H = 7    # grid height
MAZE_W = 7    # grid width